package it.eng.corso.taskservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
